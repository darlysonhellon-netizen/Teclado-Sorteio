package com.tecladosorteio.app;

import android.graphics.Color;
import android.inputmethodservice.InputMethodService;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class GiveawayKeyboardService extends InputMethodService {
    private TextView info;
    private TextView next;
    private Button insert;

    @Override
    public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(8), dp(10), dp(8));
        root.setBackgroundColor(Color.rgb(28, 28, 32));

        info = label("", 13, false);
        root.addView(info, full());

        next = label("", 21, true);
        root.addView(next, full());

        insert = button("INSERIR PRÓXIMO @");
        insert.setOnClickListener(v -> insertNext());
        root.addView(insert, full());

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button undo = button("Desfazer");
        undo.setOnClickListener(v -> undo());
        row.addView(undo, weight());

        Button other = button("Outro teclado");
        other.setOnClickListener(v -> {
            try {
                switchToNextInputMethod(false);
            } catch (Throwable e) {
                Toast.makeText(this,
                        "Use o seletor de teclado do Android.",
                        Toast.LENGTH_SHORT).show();
            }
        });
        row.addView(other, weight());

        root.addView(row, full());
        refresh();
        return root;
    }

    @Override
    public void onStartInputView(EditorInfo infoAttr, boolean restarting) {
        super.onStartInputView(infoAttr, restarting);

        int variation = infoAttr == null ? 0 :
                (infoAttr.inputType & InputType.TYPE_MASK_VARIATION);

        boolean password =
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD;

        if (insert != null) {
            insert.setEnabled(!password);
            if (password) {
                info.setText("Campo de senha detectado");
                next.setText("Troque para seu teclado normal");
            } else {
                refresh();
            }
        }
    }

    private void insertNext() {
        List<String> q = MainActivity.UserStore.queue(this);
        int idx = MainActivity.UserStore.index(this);

        if (idx >= q.size()) {
            Toast.makeText(this, "Fila concluída.", Toast.LENGTH_SHORT).show();
            refresh();
            return;
        }

        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        ic.commitText("@" + q.get(idx), 1);
        MainActivity.UserStore.setIndex(this, idx + 1);
        refresh();
    }

    private void undo() {
        int idx = MainActivity.UserStore.index(this);
        if (idx <= 0) {
            Toast.makeText(this, "Nada para desfazer.", Toast.LENGTH_SHORT).show();
            return;
        }
        MainActivity.UserStore.setIndex(this, idx - 1);
        refresh();
    }

    private void refresh() {
        if (info == null || next == null || insert == null) return;

        List<String> q = MainActivity.UserStore.queue(this);
        int idx = MainActivity.UserStore.index(this);

        info.setText("Usados: " + idx + "/" + q.size() +
                "   •   Restam: " + Math.max(0, q.size() - idx));

        if (idx < q.size()) {
            String u = q.get(idx);
            next.setText("Próximo: @" + u);
            insert.setText("INSERIR @" + u);
        } else {
            next.setText(q.isEmpty() ? "Nenhuma lista carregada" : "Fila concluída");
            insert.setText("INSERIR PRÓXIMO @");
        }
    }

    private TextView label(String value, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setPadding(dp(4), dp(5), dp(4), dp(5));
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        return b;
    }

    private LinearLayout.LayoutParams full() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }
}
