package com.tecladosorteio.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 41;
    private EditText listBox;
    private TextView stats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(32));
        scroll.addView(root);

        root.addView(text("Teclado Sorteio", 27, true));
        root.addView(text(
                "Cole os @ ou importe JSON/TXT do seu arquivo exportado do Instagram. " +
                "O teclado apenas insere o próximo @; você toca em Enviar no Instagram.",
                15, false));

        listBox = new EditText(this);
        listBox.setHint("@pessoa1\n@pessoa2\n@pessoa3");
        listBox.setMinLines(10);
        listBox.setTextColor(Color.BLACK);
        listBox.setText(joinQueue(UserStore.queue(this)));
        root.addView(listBox, full());

        Button importButton = button("Importar JSON/TXT");
        importButton.setOnClickListener(v -> chooseFiles());
        root.addView(importButton);

        Button saveButton = button("Salvar e embaralhar lista");
        saveButton.setOnClickListener(v -> saveList(true));
        root.addView(saveButton);

        stats = text("", 14, true);
        root.addView(stats);

        Button enable = button("Ativar Teclado Sorteio");
        enable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable);

        Button choose = button("Selecionar Teclado Sorteio");
        choose.setOnClickListener(v -> {
            InputMethodManager imm =
                    (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.showInputMethodPicker();
        });
        root.addView(choose);

        Button reset = button("Zerar progresso");
        reset.setOnClickListener(v -> {
            UserStore.setIndex(this, 0);
            refresh();
            Toast.makeText(this, "Progresso zerado.", Toast.LENGTH_SHORT).show();
        });
        root.addView(reset);

        root.addView(text(
                "\nUso: no Instagram, toque no campo de comentário, selecione o " +
                "Teclado Sorteio, toque em INSERIR @ e depois em Enviar no Instagram. " +
                "O próximo nome ficará preparado.\n\n" +
                "Privacidade: o app não pede permissão de Internet.",
                14, false));

        setContentView(scroll);
        refresh();
    }

    private void chooseFiles() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"application/json", "text/plain", "text/json"});
        startActivityForResult(i, PICK_FILES);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null) return;

        LinkedHashSet<String> users = parseUsers(listBox.getText().toString());

        try {
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) {
                    users.addAll(parseUsers(readUri(clip.getItemAt(i).getUri())));
                }
            } else if (data.getData() != null) {
                users.addAll(parseUsers(readUri(data.getData())));
            }

            listBox.setText(joinQueue(new ArrayList<>(users)));
            Toast.makeText(this,
                    users.size() + " perfis encontrados.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this,
                    "Não consegui ler um dos arquivos.", Toast.LENGTH_LONG).show();
        }
    }

    private String readUri(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) return "";
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private LinkedHashSet<String> parseUsers(String raw) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (raw == null) return out;

        String trimmed = raw.trim();
        boolean looksJson = trimmed.startsWith("{") || trimmed.startsWith("[");

        Pattern jsonValue = Pattern.compile(
                "\\\"value\\\"\\s*:\\s*\\\"([A-Za-z0-9._]{1,30})\\\"");
        Matcher jm = jsonValue.matcher(raw);
        while (jm.find()) out.add(jm.group(1));

        Pattern jsonTitle = Pattern.compile(
                "\\\"title\\\"\\s*:\\s*\\\"([A-Za-z0-9._]{1,30})\\\"");
        Matcher jt = jsonTitle.matcher(raw);
        while (jt.find()) out.add(jt.group(1));

        if (!looksJson) {
            Pattern atName = Pattern.compile(
                    "(?<![A-Za-z0-9._])@([A-Za-z0-9._]{1,30})");
            Matcher am = atName.matcher(raw);
            while (am.find()) out.add(am.group(1));

            for (String token : raw.split("[,;\\n\\r\\t ]+")) {
                String u = token.trim();
                if (u.startsWith("@")) u = u.substring(1);
                if (u.matches("[A-Za-z0-9._]{1,30}")) out.add(u);
            }
        }

        return out;
    }

    private void saveList(boolean shuffle) {
        List<String> q = new ArrayList<>(parseUsers(listBox.getText().toString()));
        if (shuffle) Collections.shuffle(q);
        UserStore.saveQueue(this, q);
        listBox.setText(joinQueue(q));
        refresh();
        Toast.makeText(this,
                "Lista salva com " + q.size() + " perfis.", Toast.LENGTH_LONG).show();
    }

    private void refresh() {
        List<String> q = UserStore.queue(this);
        int idx = UserStore.index(this);
        if (stats != null) {
            stats.setText("Total: " + q.size() +
                    "   |   usados: " + idx +
                    "   |   restantes: " + Math.max(0, q.size() - idx));
        }
    }

    private String joinQueue(List<String> q) {
        StringBuilder s = new StringBuilder();
        for (String u : q) s.append("@").append(u).append("\n");
        return s.toString();
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(Color.BLACK);
        t.setPadding(0, dp(6), 0, dp(6));
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        return b;
    }

    private LinearLayout.LayoutParams full() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(6), 0, dp(6));
        return p;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    public static final class UserStore {
        private static final String PREF = "teclado_sorteio";
        private static final String QUEUE = "queue";
        private static final String INDEX = "index";

        private static SharedPreferences p(Context c) {
            return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        }

        public static void saveQueue(Context c, List<String> q) {
            JSONArray arr = new JSONArray();
            for (String u : q) arr.put(u);
            p(c).edit()
                    .putString(QUEUE, arr.toString())
                    .putInt(INDEX, 0)
                    .apply();
        }

        public static List<String> queue(Context c) {
            ArrayList<String> out = new ArrayList<>();
            try {
                JSONArray arr = new JSONArray(p(c).getString(QUEUE, "[]"));
                for (int i = 0; i < arr.length(); i++) {
                    String u = arr.optString(i, "");
                    if (!u.isEmpty()) out.add(u);
                }
            } catch (Exception ignored) {}
            return out;
        }

        public static int index(Context c) {
            int i = p(c).getInt(INDEX, 0);
            return Math.max(0, Math.min(i, queue(c).size()));
        }

        public static void setIndex(Context c, int i) {
            int safe = Math.max(0, Math.min(i, queue(c).size()));
            p(c).edit().putInt(INDEX, safe).apply();
        }
    }
}
